<!DOCTYPE HTML>
<html>
<head>
<title>物品租借</title>
<meta charset="UTF-8"/>
</head>
<body>
<center>
<center>
	<h1>資訊管理系-租借系統-借閱</h1>
	<div>
				<?php
				session_start();
				if(isset($_SESSION['perID']))
				{
					echo "<a href=\"#\"><span>".$_SESSION['uid']."</span></a>";
					echo "<a href=\"logout.php\"><span>登出</span></a>";
					echo "<div class=\"line\"></div>";	
				}
				else{
					echo "<a href=\"index2.php\"><span>登入</span></a>";
				}	?>
				</div>
	<hr size="2" align="center" noshade width="70%" color="black">
	<span ><a href="borrow.php" style="text-decoration: none">物品租借&nbsp;</a></span>
	<span><a href='index.php' style='text-decoration: none'>租借紀錄&nbsp;</a></span>
	<span><a href="history.php" style="text-decoration: none">借閱歷史紀錄&nbsp;</a></span>
	<span><a href="back.php" style="text-decoration: none">後臺管理</a></span>
	<br><br>
	<h2><font color="red">請選擇你欲租借之物品，點擊後再填寫詳細資料</font></h2><p>

<?php
include('include.php');
mysqli_set_charset( $link, 'utf8');
$sql = "select * from item ";
$result = mysqli_query($link, $sql);
	echo "<table border='0'>";
while($row = mysqli_fetch_assoc($result))
{
	$i+=1;
	echo "<td><a href='form.php?item=".$row['itemNo']."'><img src='img/".$row['itemNo'].".jpg' width='200px' height='200px' border='1'></a><center>".$row['uitem']."&nbsp數量:".$row['num']."</center></td>";
	if($i==3)
	{
	echo "<tr>";
	$i=0;
	}
}
	echo "</table>";
?>
</center>
</body>
</html>