<?php
session_start();
include('include.php');
mysqli_set_charset( $link, 'utf8');

if(isset($_POST["uid"])){
	$uid=$_POST["uid"];
	$uid2=$_POST["uid2"];
	


$sql="SELECT * from user2 WHERE uid='$uid' AND uid2='$uid2'"; 
$result=mysqli_query($link,$sql);

$row=mysqli_num_rows($result);

if($row){    
	$_SESSION['perID'] = $_POST['uid'];
	echo "<script language = 'javascript'>"; 
	echo "alert('成功');location.href='index.php';"; 
	echo "</script>"; 
	$_SEESION['check']="yes";
	
	//header('Location:#');

}else{

	echo "<script language = 'javascript'>"; 
	echo "alert('輸入錯誤！請重新輸入！');location.href='index2.php';"; 
	echo "</script>"; 

 


}

}

?>