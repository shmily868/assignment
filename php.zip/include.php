<?php



$link=mysqli_connect("localhost","","","hw");




?>