<html>
<head>
<title>租借登入</title>
<meta charset="UTF-8"/>
</head>
<body>
<form action="checklog.php" method="post">
<center>
<h1>租借系統</h1>
<h1>請登入</h1>
<hr size="2" align="center" noshade width="70%" color="black">
<input type="text" name="uid" onkeyup="value=value.replace(/[\W]/g,'')" placeholder="請輸入您的學號"><p>
<input type="password" name="uid2" onkeyup="value=value.replace(/[\W]/g,'')"  placeholder="請輸入您的密碼"><p>
<input type="submit"  onClick="" value="登入">
<input type="reset"  onClick="index2.php"><p>

<a href="index.php">回租借頁面</a>

</center>
</form>
</body>
</html>
