<?php
	if($_POST["updateBtn"])
	{
include('include.php');
mysqli_set_charset( $link, 'utf8');
		$sql = "insert into item(uitem, num) value ('".$_POST['itemName']."','".$_POST['itemNum']."')";
		mysqli_query($link,$sql);
		
		$read = "select * from item where uitem = '".$_POST['itemName']."' order by itemNo DESC";
		$result = mysqli_query($link,$read);

		if($row = mysqli_fetch_assoc($result))
		{
			$type=str_replace("image/","",$_FILES["pic"]["type"]);
			if(is_file("img/".$row["itemNo"].".jpg"))
			{
				unlink("img/".$row["itemNo"].".jpg");
			}			
			if(move_uploaded_file($_FILES["pic"]["tmp_name"],"img/".$row["itemNo"].".jpg"))
			{			
			echo "<script>alert('上傳成功');</script> "; 
			}
		}
	} 
?>
<!DOCTYPE HTML>
<html>
<head>
<title>後臺管理</title>
<meta charset="UTF-8"/>	
</head>
<body>
	<center>
	<h1>資訊管理系-租借系統-後臺管理</h1>
	<div>
				<?php
				session_start();
				if(isset($_SESSION['perID']))
				{
					echo "<a href=\"#\"><span>".$_SESSION['uid']."</span></a>";
					echo "<a href=\"logout.php\"><span>登出</span></a>";
					echo "<div class=\"line\"></div>";	
				}
				else{
					echo "<a href=\"index2.php\"><span>登入</span></a>";
				}	?>
				</div>
	<hr size="2" align="center" noshade width="70%" color="black">
	<span ><a href="borrow.php" style="text-decoration: none">物品租借&nbsp;</a></span>
	<span><a href='index.php' style='text-decoration: none'>租借紀錄&nbsp;</a></span>
	<span><a href="history.php" style="text-decoration: none">借閱歷史紀錄&nbsp;</a></span>
	<span><a href="back.php" style="text-decoration: none">後臺管理</a></span>
	<br><br>

		<form method="post" enctype="multipart/form-data">
			物品名稱&nbsp;<input type="text" name="itemName" value=""/>
			物品數量&nbsp;<input type="text" name="itemNum" value="">
			上傳圖片&nbsp;<input type="file" name="pic" ><br><br>
			<input type="submit" name="updateBtn" value="新增物品">
			
		</form>
	</center>

<?php
	
		
	
	//讀取全部資料	
include('include.php');
mysqli_set_charset( $link, 'utf8');
	$sql = "SELECT * from  item "; 
	$result=mysqli_query($link,$sql);
	
	echo "<center>";
	echo "<table border='1' >";
	echo "<tr>";
	echo "<th>物品名稱</th>";
	echo "<th>物品圖</th>";
	echo "<th>物品數目</th>";
	echo "</tr>";
	while($row = mysqli_fetch_assoc($result))
	{
	echo "<tr><td>".$row["uitem"]."</td>";
	echo "<td><img style=' height: 100px;width:100px; ' src = img/".$row["itemNo"].".jpg></td>";
	echo "<td>".$row["num"]."</td></tr>";
	echo "</center>";
	}
?>
</body>
</html>