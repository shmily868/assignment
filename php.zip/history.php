<?php

?>
<!DOCTYPE HTML>
<html>
<head>
<title>歷史紀錄</title>
<meta charset="UTF-8"/>
</head>
<body>
	<center>
	<h1>資訊管理系-租借系統-歷史紀錄</h1>
	<div>
				<?php
				session_start();
				if(isset($_SESSION['perID']))
				{
					echo "<a href=\"#\"><span>".$_SESSION['uid']."</span></a>";
					echo "<a href=\"logout.php\"><span>登出</span></a>";
					echo "<div class=\"line\"></div>";	
				}
				else{
					echo "<a href=\"index2.php\"><span>登入</span></a>";
				}	?>
				</div>
	<hr size="2" align="center" noshade width="70%" color="black">
	<span ><a href="borrow.php" style="text-decoration: none">物品租借&nbsp;</a></span>
	<span><a href='index.php' style='text-decoration: none'>租借紀錄&nbsp;</a></span>
	<span><a href="history.php" style="text-decoration: none">借閱歷史紀錄&nbsp;</a></span>
	<span><a href="back.php" style="text-decoration: none">後臺管理</a></span>
	<br><br>
	<form method="POST" name="SearchForm"  onsubmit="return Search();">
	請輸入學號<input type="text" name="id" id="id">
	<input type="submit" value="查詢">
	</form>	
	<table border="1">
<?php
		if($_POST["id"]){			
include('include.php');
mysqli_set_charset( $link, 'utf8');
			$sql="select * FROM  user where uid = '".$_POST["id"]."' and isReturn=1";
			$result=mysqli_query($link,$sql);
			echo	"<tr>";
			echo	"<td>學號</td>";
			echo	"<td>項目</td>";
			echo	"<td>歸還日期</td>";
			echo	"</tr>";		
			while($row = mysqli_fetch_assoc($result))
			{
				$sql = "select * FROM item WHERE itemNo=".$row['uitem']."";
				$rows=mysqli_fetch_assoc(mysqli_query($link,$sql));			
				echo "<tr>";
				echo "<form method='POST' action='index.php?del=".$row["userNo"]."&id=".$_POST["id"]."'>";
				echo "<td>".$row["uid"]."</td>";
				echo "<td>".$rows["uitem"]."</td>";
				echo "<td>".$row["uReturnDay"]."</td>";
				echo "</form>";
				echo "</tr>";
			}
		}
	else
	{
		
	}
?>
</table>
</center>
</body>
<script>
function Search(){
	var inputid=document.getElementById('id').value;
	if(inputid!='' && inputid!=null)
	{
		//alert(inputid);
		SearchForm.submit();
		return true;
	}else
	{
		alert("請輸入學號!!");
		return false;
	}
}
</script>
</html>