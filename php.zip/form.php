<html>
<head>
<title></title>
<meta charset="UTF-8"/>
</head>
<body>
<form action="" method="post">
<center><h2><font color="red">請填寫詳細資料，以便確認</font></h2><p>


<center>
<input type="text" name="uName"  placeholder="請輸入您的姓名"><p>
<input type="text" name="uid"  placeholder="請輸入您的學號"><p>
<input type="text" name="uphone"  placeholder="請輸入您的聯絡電話"><p>
<p>請選擇借閱天數&nbsp;<input  type="number" max="10" min="1" name="limitDay"/ placeholder="上限:10"></p>
是否押證件?<p>
<input type="radio" name="idon"  value="是">是
<input type="radio" name="idon"  value="否">否<p>
<input type="submit" name="submit" onClick="" value="確認">
<input type="reset">
<input  type="button" onclick="location.href='http://localhost/borrow.php'" value="回租借頁面"/>
</center>
</form>
<?php


include('include.php');
mysqli_set_charset( $link, 'utf8');
if($_POST["submit"])
{
	

if(isset($_POST["uName"])  && isset($_POST["uphone"]) && isset($_POST["idon"]) && isset($_POST["limitDay"])){
	$uName=$_POST["uName"];
	$uid=$_POST["uid"];
	$uphone=$_POST["uphone"];
	$idon=$_POST["idon"];

$limitDay = $_POST["limitDay"];
$limitDay = date('Y-m-d', time() + $limitDay * 86400);


$sql = 'CREATE DATABASE hw DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci';
mysqli_query($link,$sql);

mysqli_select_db($link,"hw");
$sql = "INSERT INTO user(uName, uid, uphone, idon, uday, uitem) VALUES ('$uName', '$uid','$uphone','$idon', '$limitDay', ".$_GET['item'].")";
mysqli_query($link, $sql);


$sql = "SELECT num FROM item WHERE  itemNo = ".$_GET['item']."";
$row=mysqli_fetch_assoc(mysqli_query($link,$sql));
	

	$sql = "UPDATE item SET num = ".($row['num'] - 1)." WHERE itemNo = ".$_GET['item']."";
	mysqli_query($link, $sql);

	echo "<script type=\"text/javascript\">alert('借閱成功');</script>";
	echo "<script>document.location.href=\"http://localhost/index.php\";</script>";
	
}
else
{
	echo "<script>alert('輸入錯誤！請重新輸入！');</script> "; 
}

}
?>
</body>
</html>



