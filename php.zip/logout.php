<?php
session_start();
unset($_SESSION['perID']);
					$msg="請重新登入";
					echo "<script type=\"text/javascript\">alert('$msg');</script>";
 					echo "<script>document.location.href=\"http://localhost/index.php\";</script>";
?>