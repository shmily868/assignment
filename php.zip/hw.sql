-- phpMyAdmin SQL Dump
-- version 4.4.9
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 產生時間： 2016-04-16 17:39:57
-- 伺服器版本: 10.0.19-MariaDB
-- PHP 版本： 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `hw`
--

-- --------------------------------------------------------

--
-- 資料表結構 `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `itemNo` int(255) NOT NULL,
  `uitem` varchar(20) NOT NULL,
  `num` varchar(20) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `item`
--

INSERT INTO `item` (`itemNo`, `uitem`, `num`) VALUES
(1, '嘜克風', '6'),
(2, '精選覆耳式耳機', '9'),
(3, 'Asus 14吋筆電', '3'),
(4, '高檔激光遙控筆', '10'),
(5, 'HD 攝錄機 HDR-CX520V', '2'),
(6, '高質大聲公', '2'),
(7, 'ACER X1270 3D投影機', '0'),
(8, '延長線', '10'),
(9, '嘜克風電池', '30'),
(10, '雨傘', '15'),
(11, '無尾熊', '9'),
(12, '菊花', '9');

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userNo` int(11) NOT NULL,
  `uName` varchar(20) NOT NULL,
  `uid` varchar(50) NOT NULL,
  `uphone` varchar(255) NOT NULL,
  `idon` varchar(2) NOT NULL,
  `uday` date NOT NULL,
  `uitem` varchar(50) NOT NULL,
  `isReturn` tinyint(1) NOT NULL,
  `uReturnDay` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `user`
--

INSERT INTO `user` (`userNo`, `uName`, `uid`, `uphone`, `idon`, `uday`, `uitem`, `isReturn`, `uReturnDay`) VALUES
(48, '雷嘉鳴', 'A1023350', '0', '是', '0000-00-00', '', 0, '0000-00-00'),
(50, '王凱駿', 'a111111', '0', '是', '0000-00-00', '1', 1, '2016-04-12'),
(51, '王凱駿', 'a111111', '0111', '是', '0000-00-00', '2', 1, '2016-04-12'),
(52, '', '', '', '', '2016-04-13', '', 0, '0000-00-00'),
(53, '', '', '', '', '2016-07-20', '', 0, '0000-00-00'),
(54, 'd', 's', 'a', '是', '2016-04-13', '1', 0, '0000-00-00'),
(55, 'a', 's', 's', '是', '2016-04-12', '1', 0, '0000-00-00'),
(56, '王凱駿', 'a111111', '1', '是', '2016-04-13', '1', 0, '2016-04-12'),
(57, '王凱駿', 'a1023354', '07', '是', '2016-04-15', '2', 1, '2016-04-12'),
(58, '小御', 'a101', '07111111', '是', '2016-04-18', '6', 0, '0000-00-00'),
(59, '小', 'a111', '07123456', '是', '2016-04-18', '1', 1, '2016-04-16'),
(60, '王凱駿', 'a1023354', '0111', '是', '2016-04-21', '1', 0, '0000-00-00'),
(61, '王凱駿', 'a1023354', '1', '是', '2016-04-18', '2', 0, '0000-00-00'),
(62, '王凱駿', 'a1023354', '1', '是', '2016-04-18', '1', 0, '0000-00-00'),
(63, '王凱駿', 'a1023354', '076663363', '是', '2016-04-21', '11', 1, '2016-04-16'),
(64, '王凱駿', 'a1023354', '07456123', '是', '2016-04-18', '11', 0, '0000-00-00'),
(65, '王凱駿', 'a1023354', '1', '是', '2016-04-17', '7', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- 資料表結構 `user2`
--

CREATE TABLE IF NOT EXISTS `user2` (
  `uid` varchar(20) NOT NULL,
  `uid2` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `user2`
--

INSERT INTO `user2` (`uid`, `uid2`) VALUES
('a1023350', 'a1023350'),
('a1023354', 'a1023354');

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`itemNo`);

--
-- 資料表索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userNo`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `item`
--
ALTER TABLE `item`
  MODIFY `itemNo` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- 使用資料表 AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `userNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=66;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
